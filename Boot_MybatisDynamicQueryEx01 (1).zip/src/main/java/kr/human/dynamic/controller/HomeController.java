package kr.human.dynamic.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import kr.human.dynamic.service.EmployeesService;
import kr.human.dynamic.service.TestService;
import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
public class HomeController {

	@Autowired
	private TestService testService;
	
	@Autowired 
	private EmployeesService employeesService;
	
	@RequestMapping(value = {"/","/index","/home"})
	public String index(Model model) {
		model.addAttribute("today", testService.today());
		return "index";
	}
	
	@RequestMapping(value = "/list1")
	public String list1(@RequestParam(required = false) String department_id,  Model model) {
		log.info("{} 의 list1메서드 호출 : {}", this.getClass().getName(), department_id);
		model.addAttribute("deptList", employeesService.selectDepartment());
		model.addAttribute("empList", employeesService.selectList(department_id));
		model.addAttribute("deptid", department_id);
		return "list";
	}
	@RequestMapping(value = "/list2")
	public String list2(@RequestParam(required = false) List<String> list,  Model model) {
		log.info("{} 의 list2메서드 호출 : {}", this.getClass().getName(), list);
		model.addAttribute("deptList", employeesService.selectDepartment());
		model.addAttribute("empList", employeesService.selectList2(list));
		model.addAttribute("list", list);
		return "list2";
	}
}
