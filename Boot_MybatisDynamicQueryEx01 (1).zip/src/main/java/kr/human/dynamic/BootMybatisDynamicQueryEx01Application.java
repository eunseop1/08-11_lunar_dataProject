package kr.human.dynamic;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootMybatisDynamicQueryEx01Application {

	public static void main(String[] args) {
		SpringApplication.run(BootMybatisDynamicQueryEx01Application.class, args);
	}

}
