package kr.human.dynamic.vo;

import lombok.Data;

/*
 	DEPARTMENTS
	"DEPARTMENT_ID" NUMBER(4,0), 
	"DEPARTMENT_NAME" VARCHAR2(30) CONSTRAINT "DEPT_NAME_NN" NOT NULL ENABLE, 
	"MANAGER_ID" NUMBER(6,0), 
	"LOCATION_ID" NUMBER(4,0), 
 */
@Data
public class Departments {
	private int department_id;
	private String department_name;
	private int manager_id;
	private int location_id;
}
