package kr.human.dynamic.vo;

import java.util.Date;

import lombok.Data;

/*
EMPLOYEE_ID
FIRST_NAME
LAST_NAME
EMAIL
PHONE_NUMBER
HIRE_DATE
JOB_ID
SALARY
COMMISSION_PCT
MANAGER_ID
DEPARTMENT_ID
 */
@Data
public class Employees {
	private int employee_id;
	private String first_name;
	private String last_name;
	private String email;
	private String phone_number;
	private Date   hire_date;
	private String job_id;
	private Double salary;
	private Double commission_pct;
	private Double manager_id;
	private Double department_id;
}
