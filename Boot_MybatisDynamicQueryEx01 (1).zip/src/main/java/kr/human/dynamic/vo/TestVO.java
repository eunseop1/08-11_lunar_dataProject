package kr.human.dynamic.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class TestVO {
	private String 	today;
	private int 	sum;
	private int 	mul;
	private int 	num1;
	private int 	num2;
}

