package kr.human.dynamic.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.human.dynamic.dao.EmployeesDAO;
import kr.human.dynamic.vo.Departments;
import kr.human.dynamic.vo.Employees;
import lombok.extern.slf4j.Slf4j;

@Service("employeesService")
@Slf4j
public class EmployeesServiceImpl implements EmployeesService {

	@Autowired
	private EmployeesDAO employeesDAO;
	
	@Override
	public List<Employees> selectList(String department_id) {
		log.info("{} 의 list1메서드 호출 : {}", this.getClass().getName(), department_id);
		return employeesDAO.selectList(department_id);
	}
	@Override
	public List<Departments> selectDepartment() {
		return employeesDAO.selectDepartment();
	}
	@Override
	public List<Employees> selectList2(List<String> list) {
		log.info("{} 의 list1메서드 호출 : {}", this.getClass().getName(), list);
		return employeesDAO.selectList2(list);
	}
}
