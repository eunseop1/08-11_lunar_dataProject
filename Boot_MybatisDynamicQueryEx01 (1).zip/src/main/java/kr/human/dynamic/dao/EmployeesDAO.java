package kr.human.dynamic.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import kr.human.dynamic.vo.Departments;
import kr.human.dynamic.vo.Employees;

@Mapper
public interface EmployeesDAO {
	List<Employees> selectList(String department_id);
	List<Employees> selectList2(List<String> list);
	List<Departments> selectDepartment();
}
