package kr.human.dynamic.service;

import java.util.List;

import kr.human.dynamic.vo.Departments;
import kr.human.dynamic.vo.Employees;

public interface EmployeesService {
	List<Employees> selectList(String department_id);
	List<Departments> selectDepartment();
}
